#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
#
# Université de Lorraine - Licence informatique
# Fichier d'init du module d'informatique graphique : ig
# utilisant le module pygame
#
################################################################################

################################################################################
# Chargement des différents fichiers communs
################################################################################
import ecran as ecr
import donnees as don
from affichage import *
################################################################################

